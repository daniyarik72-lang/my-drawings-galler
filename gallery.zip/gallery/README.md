# Галерея рисунков

Статический сайт-галерея на **Astro** с админ-панелью **Sveltia CMS**. Админ добавляет рисунки и подписи через браузер (`/admin/`), контент сохраняется коммитами в Git-репозиторий, а GitHub Actions автоматически собирает сайт и публикует его на GitHub Pages. Серверов, баз данных и платных сервисов нет.

## Для разработчика: локальный запуск

```bash
npm i
npm run dev      # сайт на http://localhost:4321/ИМЯ-РЕПОЗИТОРИЯ/
npm run build    # production-сборка в папку dist/
```

Логин и имя репозитория задаются в `astro.config.mjs` (строки с `GH_USER` и `GH_REPO`) или через переменные окружения. Локально: `GH_USER=ivan GH_REPO=gallery npm run dev`.

## Первый запуск: что сделать руками

1. Создайте на GitHub пустой репозиторий (например, `gallery`).
2. В `public/admin/config.yml` замените `repo: ВАШ-ЛОГИН/ИМЯ-РЕПОЗИТОРИЯ` на свои значения.
3. Выполните:
   ```bash
   git init && git add . && git commit -m "init"
   git branch -M main
   git remote add origin https://github.com/ЛОГИН/РЕПО.git
   git push -u origin main
   ```
4. В репозитории: **Settings → Pages → Source: GitHub Actions**.
5. Настройте авторизацию для админки (см. ниже).
6. Через 1–2 минуты сайт откроется на `https://ЛОГИН.github.io/РЕПО/`.

После каждого `git push` в `main` запускается workflow `deploy.yml`: сборка Astro, загрузка артефакта и публикация на Pages.

## Авторизация админки через GitHub (OAuth)

Sveltia CMS входит в GitHub через OAuth. У GitHub Pages нет серверной части, поэтому нужен маленький OAuth-прокси. Есть два варианта.

### Вариант А. Свой прокси `sveltia-cms-auth` на Cloudflare Workers (рекомендуется, ~5 минут)

1. Создайте OAuth App: GitHub → **Settings → Developer settings → OAuth Apps → New OAuth App**.
   - Application name: любое, например `Gallery CMS`.
   - Homepage URL: `https://ЛОГИН.github.io/РЕПО/`.
   - Authorization callback URL: временно `https://example.com/callback` (исправите на шаге 4).
2. Нажмите **Generate a new client secret** и сохраните Client ID и Client Secret.
3. Зарегистрируйтесь на cloudflare.com (бесплатно). Задеплойте воркер из репозитория `sveltia/sveltia-cms-auth` (инструкция в его README: кнопка Deploy или `wrangler deploy`). Получите адрес вида `https://sveltia-cms-auth.ВАШ-АККАУНТ.workers.dev`.
4. В настройках воркера (**Settings → Variables and Secrets**) добавьте:
   - `GITHUB_CLIENT_ID` — Client ID;
   - `GITHUB_CLIENT_SECRET` — Client Secret (тип Secret);
   - `ALLOWED_DOMAINS` — `ЛОГИН.github.io`.
   Затем в OAuth App замените Authorization callback URL на `https://sveltia-cms-auth.ВАШ-АККАУНТ.workers.dev/callback`.
5. В `public/admin/config.yml` раскомментируйте и заполните:
   ```yaml
   backend:
     base_url: https://sveltia-cms-auth.ВАШ-АККАУНТ.workers.dev
   ```
6. `git push`. Готово.

### Вариант Б. Без прокси: вход по Personal Access Token

Sveltia CMS умеет входить по токену, поэтому OAuth-прокси не нужен (удобно для одного админа).

1. GitHub → **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**.
2. Выберите только этот репозиторий. В **Repository permissions** дайте `Contents: Read and write`.
3. Скопируйте токен. На странице входа в админку выберите «Sign in with token» и вставьте его. Токен хранится только в вашем браузере.

Оставьте `base_url` закомментированным. Если нужен вход кнопкой «Войти через GitHub» для нескольких админов, используйте вариант А.

## Инструкция для админа (без программирования)

### Как зайти
1. Откройте `https://ЛОГИН.github.io/РЕПО/admin/`.
2. Нажмите **Sign in with GitHub** (вход по токену описан выше) и разрешите доступ. Ваш аккаунт должен иметь право записи в репозиторий.

### Как добавить рисунок
1. На экране слева — раздел **Рисунки**. Вверху нажмите **Новая запись** (кнопка «+»).
2. В поле **Рисунок** нажмите «Выбрать файл» (или перетащите картинку) и загрузите jpg, png или webp.
3. В поле **Подпись** введите текст, который будет под рисунком.
4. По желанию: **Порядок** (число, чем меньше, тем выше рисунок в сетке) и **Дата добавления**. Если порядок не задан, новые рисунки идут первыми.
5. Нажмите **Опубликовать → Опубликовать сейчас** в правом верхнем углу.
6. Изменения появятся на сайте через **1–2 минуты** (пока идёт сборка). Статус виден во вкладке Actions репозитория.

Чтобы изменить или удалить рисунок, откройте его в списке и нажмите «Сохранить» или «Удалить» (меню «…»).

> Совет: загружайте картинки до 3–4 МБ. Сайт сам уменьшит их и преобразует в webp.

## Как поменять название галереи

Файл `src/pages/index.astro`, строка `const SITE_TITLE = 'Галерея рисунков';` (около 7-й строки). Замените текст в кавычках.

## Как поменять цвета и стиль

Файл `src/styles/global.css`, блок `:root` в самом верху. Там CSS-переменные: `--bg` (фон), `--text` (цвет текста), `--muted` (цвет подписей), `--card-bg` (фон карточки), `--radius` (скругление), `--gap` (отступы сетки), `--shadow` и `--shadow-hover` (тени).

## Troubleshooting

**Пустая страница или сайт без стилей.** Обычно неверный `base`. Проверьте `GH_USER` и `GH_REPO` в `astro.config.mjs` или то, что workflow подставляет их автоматически. Адрес сайта должен быть `https://ЛОГИН.github.io/РЕПО/` (со слэшем на конце).

**Ошибка base path (404 на CSS/картинки, «/РЕПО/» не найден).** Имя репозитория в `GH_REPO` должно совпадать с реальным. Для репозитория `ЛОГИН.github.io` base автоматически `/`.

**Картинки не грузятся.** Проверьте, что файл лежит в `public/uploads/`, расширение jpg/jpeg/png/webp и что в записи путь вида `/uploads/имя.jpg`. Если картинка не найдена, карточка выводится только с подписью.

**Админка не открывается или не даёт войти.** Убедитесь, что в `config.yml` правильно указан `repo`, ветка `main` и (для варианта А) `base_url`. Проверьте, что у аккаунта есть право записи в репозиторий.

**Сайт не обновился после публикации.** Откройте вкладку **Actions** в репозитории: если сборка красная, откройте лог. Убедитесь, что в **Settings → Pages** выбран Source: GitHub Actions.
