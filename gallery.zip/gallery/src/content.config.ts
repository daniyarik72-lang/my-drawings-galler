import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

// Коллекция "Рисунки": каждый .md файл — один рисунок (создаётся через CMS)
const drawings = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/drawings' }),
  schema: z.object({
    image: z.string(), // путь вида /uploads/file.jpg (из public/uploads)
    caption: z.string(),
    order: z.number().optional(),
    date: z.coerce.date().optional(),
  }),
});

export const collections = { drawings };
