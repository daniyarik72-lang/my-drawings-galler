---
image: /uploads/example.png
caption: Пример рисунка (удалите через админку)
order: 1
date: 2026-10-21
---
