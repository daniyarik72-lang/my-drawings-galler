import { defineConfig } from 'astro/config';

// ====== НАСТРОЙКИ ДЛЯ GITHUB PAGES (поменяйте под себя) ======
// Можно задать через переменные окружения (в deploy.yml они подставляются автоматически)
// или просто вписать значения вручную вместо 'ВАШ-ЛОГИН' и 'ИМЯ-РЕПОЗИТОРИЯ'.
const user = process.env.GH_USER || 'ВАШ-ЛОГИН';
const repo = process.env.GH_REPO || 'ИМЯ-РЕПОЗИТОРИЯ';

// Если репозиторий называется <логин>.github.io (user-page), поставьте base = '/'
const isUserPage = repo.toLowerCase() === `${user.toLowerCase()}.github.io`;

export default defineConfig({
  site: `https://${user}.github.io`,
  base: isUserPage ? '/' : `/${repo}/`,
  trailingSlash: 'always',
});
