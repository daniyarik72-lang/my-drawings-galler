import { defineConfig } from 'astro/config';

// ====== НАСТРОЙКИ ДЛЯ GITHUB PAGES (поменяйте под себя) ======
// Можно задать через переменные окружения (в deploy.yml они подставляются автоматически)
// или просто вписать значения вручную вместо 'daniyarik72-lang' и 'my-drawings-galler'.
const user = process.env.GH_USER || 'daniyarik72-lang';
const repo = process.env.GH_REPO || 'my-drawings-galler';

// Если репозиторий называется <логин>.github.io (user-page), поставьте base = '/'
const isUserPage = repo.toLowerCase() === `${user.toLowerCase()}.github.io`;

export default defineConfig({
  site: `https://${user}.github.io`,
  base: isUserPage ? '/' : `/${repo}/`,
  trailingSlash: 'always',
});
